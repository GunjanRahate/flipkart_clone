export const fashionProductData = [
    {
        img : "https://rukminim2.flixcart.com/image/170/170/xif0q/gown/b/2/1/na-xl-3-4-sleeve-stitched-tak-0108-pink-taktke-na-original-imaggybnzfzrk2ch.jpeg?q=90",
        name : "Trendy Gowns",
        discount : "Under ₹699",
        brand : "",
        link : "https://www.flipkart.com/clothing-and-accessories/dresses-and-gown/gown/women-gown/pr?sid=clo%2Codx%2Cod7%2C0xx&p%5B%5D=facets.price_range.from%3DMin&p%5B%5D=facets.price_range.to%3D699&hpid=5pSAaEQbdcez-iJdvYVP-qp7_Hsxr70nj65vMAAFKlc%3D&ctx=eyJjYXJkQ29udGV4dCI6eyJhdHRyaWJ1dGVzIjp7InZhbHVlQ2FsbG91dCI6eyJtdWx0aVZhbHVlZEF0dHJpYnV0ZSI6eyJrZXkiOiJ2YWx1ZUNhbGxvdXQiLCJpbmZlcmVuY2VUeXBlIjoiVkFMVUVfQ0FMTE9VVCIsInZhbHVlcyI6WyJVbmRlciDigrk2OTkiXSwidmFsdWVUeXBlIjoiTVVMVElfVkFMVUVEIn19LCJoZXJvUGlkIjp7InNpbmdsZVZhbHVlQXR0cmlidXRlIjp7ImtleSI6Imhlcm9QaWQiLCJpbmZlcmVuY2VUeXBlIjoiUElEIiwidmFsdWUiOiJHV05HVTJYNVM2TVVFTUdGIiwidmFsdWVUeXBlIjoiU0lOR0xFX1ZBTFVFRCJ9fSwidGl0bGUiOnsibXVsdGlWYWx1ZWRBdHRyaWJ1dGUiOnsia2V5IjoidGl0bGUiLCJpbmZlcmVuY2VUeXBlIjoiVElUTEUiLCJ2YWx1ZXMiOlsiVHJlbmR5IEdvd25zIl0sInZhbHVlVHlwZSI6Ik1VTFRJX1ZBTFVFRCJ9fX19fQ%3D%3D",
    },
    {
        img : "https://rukminim2.flixcart.com/image/170/170/xif0q/shoe/s/c/x/-original-imagn9na9ysruzgs.jpeg?q=90",
        name : "Shoes",
        discount : "Min 40% OFF",
        brand : "Puma, Adidas",
        link : "https://www.flipkart.com/womens-footwear/~sports-casual-shoes/pr?sid=osp%2Ciko&p%5B%5D=facets.brand%255B%255D%3DKILLER&param=159&p%5B%5D=facets.brand%255B%255D%3DTOMMY%2BHILFIGER&p%5B%5D=facets.brand%255B%255D%3DFILA&p%5B%5D=facets.brand%255B%255D%3DREEBOK%2BCLASSICS&p%5B%5D=facets.brand%255B%255D%3DRoadster&p%5B%5D=facets.brand%255B%255D%3DNew%2BBalance&p%5B%5D=facets.brand%255B%255D%3DAsics&p%5B%5D=facets.brand%255B%255D%3DCultsport&p%5B%5D=facets.brand%255B%255D%3DADIDAS%2BORIGINALS&p%5B%5D=facets.brand%255B%255D%3DRED%2BTAPE&p%5B%5D=facets.brand%255B%255D%3DREEBOK&p%5B%5D=facets.brand%255B%255D%3DHRX%2Bby%2BHrithik%2BRoshan&p%5B%5D=facets.brand%255B%255D%3DADIDAS&p%5B%5D=facets.brand%255B%255D%3DNIKE&p%5B%5D=facets.brand%255B%255D%3DSkechers&p%5B%5D=facets.brand%255B%255D%3DBROOKS&p%5B%5D=facets.brand%255B%255D%3DALDO&p%5B%5D=facets.brand%255B%255D%3DPUMA&p%5B%5D=facets.discount_range_v1%255B%255D%3D40%2525%2Bor%2Bmore&param=876&hpid=e-oRww-YWZQSY-y9hYmCV6p7_Hsxr70nj65vMAAFKlc%3D&ctx=eyJjYXJkQ29udGV4dCI6eyJhdHRyaWJ1dGVzIjp7InZhbHVlQ2FsbG91dCI6eyJtdWx0aVZhbHVlZEF0dHJpYnV0ZSI6eyJrZXkiOiJ2YWx1ZUNhbGxvdXQiLCJpbmZlcmVuY2VUeXBlIjoiVkFMVUVfQ0FMTE9VVCIsInZhbHVlcyI6WyJNaW4uIDQwJSBPZmYiXSwidmFsdWVUeXBlIjoiTVVMVElfVkFMVUVEIn19LCJoZXJvUGlkIjp7InNpbmdsZVZhbHVlQXR0cmlidXRlIjp7ImtleSI6Imhlcm9QaWQiLCJpbmZlcmVuY2VUeXBlIjoiUElEIiwidmFsdWUiOiJTSE9HR1cyUkhFVVpHWEFVIiwidmFsdWVUeXBlIjoiU0lOR0xFX1ZBTFVFRCJ9fSwidGl0bGUiOnsibXVsdGlWYWx1ZWRBdHRyaWJ1dGUiOnsia2V5IjoidGl0bGUiLCJpbmZlcmVuY2VUeXBlIjoiVElUTEUiLCJ2YWx1ZXMiOlsiUHVtYSwgQWRpZGFzIC4uLiJdLCJ2YWx1ZVR5cGUiOiJNVUxUSV9WQUxVRUQifX19fX0%3D",
    },
    {
        img : "https://rukminim2.flixcart.com/image/170/170/ktyp8cw0/t-shirt/a/y/n/s-14806378-mast-harbour-original-imag76r6ba6kgj8f.jpeg?q=90",
        name : "Being Human,Ruf & Tuf",
        discount : "Min 50% OFF",
        brand : "",
        link : "https://www.flipkart.com/clothing-and-accessories/~cs-z9p6r6232o/pr?sid=clo&collection-tab-name=T-shirts%2C+Jeans&p%5B%5D=facets.discount_range_v1%255B%255D%3D50%2525%2Bor%2Bmore&sort=recency_desc&p%5B%5D=facets.brand%255B%255D%3DKETCH&p%5B%5D=facets.brand%255B%255D%3DFOREVER%2B21&p%5B%5D=facets.brand%255B%255D%3DMast%2B%2526%2BHarbour&p%5B%5D=facets.brand%255B%255D%3DHERE%2526NOW&p%5B%5D=facets.brand%255B%255D%3DLEE&p%5B%5D=facets.brand%255B%255D%3DWrangler&p%5B%5D=facets.brand%255B%255D%3DNIVIA&p%5B%5D=facets.brand%255B%255D%3DCAMPUS%2BSUTRA&p%5B%5D=facets.brand%255B%255D%3DAcademy%2BBy%2BVan%2BHeusen&hpid=kOnR89rY_hRg68w4413XC6p7_Hsxr70nj65vMAAFKlc%3D&ctx=eyJjYXJkQ29udGV4dCI6eyJhdHRyaWJ1dGVzIjp7InZhbHVlQ2FsbG91dCI6eyJtdWx0aVZhbHVlZEF0dHJpYnV0ZSI6eyJrZXkiOiJ2YWx1ZUNhbGxvdXQiLCJpbmZlcmVuY2VUeXBlIjoiVkFMVUVfQ0FMTE9VVCIsInZhbHVlcyI6WyJNaW4uIDUwJSBPZmYiXSwidmFsdWVUeXBlIjoiTVVMVElfVkFMVUVEIn19LCJoZXJvUGlkIjp7InNpbmdsZVZhbHVlQXR0cmlidXRlIjp7ImtleSI6Imhlcm9QaWQiLCJpbmZlcmVuY2VUeXBlIjoiUElEIiwidmFsdWUiOiJUU0hHV1U0SFpNRjZVUDdEIiwidmFsdWVUeXBlIjoiU0lOR0xFX1ZBTFVFRCJ9fSwidGl0bGUiOnsibXVsdGlWYWx1ZWRBdHRyaWJ1dGUiOnsia2V5IjoidGl0bGUiLCJpbmZlcmVuY2VUeXBlIjoiVElUTEUiLCJ2YWx1ZXMiOlsiQmVpbmcgSHVtYW4sIFJ1ZiAmIFR1ZiwgTGVlLi4iXSwidmFsdWVUeXBlIjoiTVVMVElfVkFMVUVEIn19fX19",
    },
    {
        img : "https://rukminim2.flixcart.com/image/170/170/l3bx5e80/ethnic-set/x/a/n/m-vnk3003672-vishudh-original-imagegw468vxaqwz.jpeg?q=90",
        name : "Kurta sets",
        discount : "Under ₹599",
        brand : "",
        link : "https://www.flipkart.com/clothing-and-accessories/kurtas-ethnic-sets-and-bottoms/~cs-13dtsg50bc/pr?sid=clo%2Ccfv&collection-tab-name=Kurtas+-+Sets&p%5B%5D=facets.brand%255B%255D%3DLIBAS&p%5B%5D=facets.brand%255B%255D%3DIndo%2BEra&p%5B%5D=facets.brand%255B%255D%3DVishudh&p%5B%5D=facets.brand%255B%255D%3DANOUK&p%5B%5D=facets.brand%255B%255D%3DVaranga&p%5B%5D=facets.brand%255B%255D%3DBIBA&p%5B%5D=facets.brand%255B%255D%3DW&p%5B%5D=facets.brand%255B%255D%3DAurelia&p%5B%5D=facets.brand%255B%255D%3DSangria&p%5B%5D=facets.brand%255B%255D%3DJanasya&p%5B%5D=facets.brand%255B%255D%3DShae%2Bby%2BSASSAFRAS&p%5B%5D=facets.brand%255B%255D%3DHERE%2526NOW&p%5B%5D=facets.brand%255B%255D%3DMETRO-FASHION&p%5B%5D=facets.brand%255B%255D%3Dmokshi&p%5B%5D=facets.brand%255B%255D%3Dindyes&p%5B%5D=facets.discount_range_v1%255B%255D%3D70%2525%2Bor%2Bmore&hpid=kgcj7UKZT2fdR0rNzRIC_Kp7_Hsxr70nj65vMAAFKlc%3D&ctx=eyJjYXJkQ29udGV4dCI6eyJhdHRyaWJ1dGVzIjp7InZhbHVlQ2FsbG91dCI6eyJtdWx0aVZhbHVlZEF0dHJpYnV0ZSI6eyJrZXkiOiJ2YWx1ZUNhbGxvdXQiLCJpbmZlcmVuY2VUeXBlIjoiVkFMVUVfQ0FMTE9VVCIsInZhbHVlcyI6WyJNaW4gNzAlIE9mZiJdLCJ2YWx1ZVR5cGUiOiJNVUxUSV9WQUxVRUQifX0sImhlcm9QaWQiOnsic2luZ2xlVmFsdWVBdHRyaWJ1dGUiOnsia2V5IjoiaGVyb1BpZCIsImluZmVyZW5jZVR5cGUiOiJQSUQiLCJ2YWx1ZSI6IkVUSEdERTU0TVJNMlpCVEciLCJ2YWx1ZVR5cGUiOiJTSU5HTEVfVkFMVUVEIn19LCJ0aXRsZSI6eyJtdWx0aVZhbHVlZEF0dHJpYnV0ZSI6eyJrZXkiOiJ0aXRsZSIsImluZmVyZW5jZVR5cGUiOiJUSVRMRSIsInZhbHVlcyI6WyJLdXJ0YSBTZXRzIl0sInZhbHVlVHlwZSI6Ik1VTFRJX1ZBTFVFRCJ9fX19fQ%3D%3D",
    },
    {
        img : "https://rukminim2.flixcart.com/image/220/220/xif0q/t-shirt/y/7/s/l-men-s-stylish-trendy-half-sleeve-digital-printed-latest-design-original-imagqz69mu8sryvh.jpeg?q=90",
        name : "Men's T-shirt",
        discount : "Min 50% OFF",
        brand : "",
        link : "https://www.flipkart.com/all/~cs-89a4af89beda2604cb8435b235dee6f1/pr?sid=clo,ash,ank,edy&marketplace=FLIPKART&restrictLocale=true",
    },
    {
        img : "https://rukminim2.flixcart.com/image/220/220/xif0q/sari/a/b/t/free-satin-half-half-saree-pd-cloth-villa-unstitched-original-imagthn7bczd9fct.jpeg?q=90",
        name : "Women's Sarees",
        discount : "50% OFF",
        brand : "",
        link : "https://www.flipkart.com/all/~cs-c6d1c0bc13f17c317f6447e890166c33/pr?sid=clo,8on,zpd,9og&marketplace=FLIPKART&restrictLocale=true",
    },
    {
        img : "https://rukminim2.flixcart.com/image/170/170/xif0q/shirt/5/e/s/l-nb-sh-3742-pnk-nobarr-original-imaguf2yrca2duph.jpeg?q=90",
        name : "Women's Shirt",
        discount : "Min 70% OFF",
        brand : "",
        link : "https://www.flipkart.com/womens-shirts/pr?sid=clo%2Cash%2Caxc%2Cvop&p%5B%5D=facets.discount_range_v1%255B%255D%3D70%2525%2Bor%2Bmore&hpid=iwPvF5cqV-q9Q7MI3qtbD6p7_Hsxr70nj65vMAAFKlc%3D&ctx=eyJjYXJkQ29udGV4dCI6eyJhdHRyaWJ1dGVzIjp7InZhbHVlQ2FsbG91dCI6eyJtdWx0aVZhbHVlZEF0dHJpYnV0ZSI6eyJrZXkiOiJ2YWx1ZUNhbGxvdXQiLCJpbmZlcmVuY2VUeXBlIjoiVkFMVUVfQ0FMTE9VVCIsInZhbHVlcyI6WyJNaW4gNzAlIE9mZiJdLCJ2YWx1ZVR5cGUiOiJNVUxUSV9WQUxVRUQifX0sImhlcm9QaWQiOnsic2luZ2xlVmFsdWVBdHRyaWJ1dGUiOnsia2V5IjoiaGVyb1BpZCIsImluZmVyZW5jZVR5cGUiOiJQSUQiLCJ2YWx1ZSI6IlNIVEdORldQWlJZS0c4WVUiLCJ2YWx1ZVR5cGUiOiJTSU5HTEVfVkFMVUVEIn19LCJ0aXRsZSI6eyJtdWx0aVZhbHVlZEF0dHJpYnV0ZSI6eyJrZXkiOiJ0aXRsZSIsImluZmVyZW5jZVR5cGUiOiJUSVRMRSIsInZhbHVlcyI6WyJXb21lbidzIFNoaXJ0cyJdLCJ2YWx1ZVR5cGUiOiJNVUxUSV9WQUxVRUQifX19fX0%3D",
    }

]