export const imageSlider = [
    {
        image : "https://rukminim2.flixcart.com/fk-p-flap/1600/270/image/b2132b52f8b2c7dd.jpg?q=20",
        link : "https://www.flipkart.com/poco-x6-neo-5g-martian-orange-128-gb/p/itmb53368ff4b262?pid=MOBGYQ6BFZJ9RHDD&param=27890",
    },
    {
        image : "https://rukminim2.flixcart.com/fk-p-flap/1600/270/image/b53cc84af2768bdb.jpg?q=20",
        link : "https://www.flipkart.com/poco-x6-neo-5g-martian-orange-128-gb/p/itmb53368ff4b262?pid=MOBGYQ6BFZJ9RHDD&param=27890",
    },
    {
        image : "https://rukminim2.flixcart.com/fk-p-flap/1600/270/image/59b4f0a4692fc280.png?q=20",
        link : "https://www.flipkart.com/summer-festive-days-store?param=621821",
    },
    {
        image : "https://rukminim2.flixcart.com/fk-p-flap/1600/270/image/68959fd7d83448b8.png?q=20",
        link : "https://www.flipkart.com/summer-festive-days-store?param=621821",
    },
    {
        image : "https://rukminim2.flixcart.com/fk-p-flap/1600/270/image/67bdb22c1fd23512.jpg?q=20",
        link : "https://www.flipkart.com/summer-festive-days-store?param=621821",
    }
]