import { featureProductNav } from "./Data/featureProductNav.js";
import { imageSlider } from "./Data/imageSlider.js";
import { electronicsProductData } from "./Data/electronicProduct.js";
import { fashionProductData } from "./Data/fashion.js";
import { homeKitchenProductData } from "./Data/homeKitchen.js";

let input_search = document.getElementById("search_input");
let form_search = document.getElementById("search_form");
let recent_searchEl = document.querySelector(".recent_search");
let recentArray = ["mobile", "phone"];

form_search.addEventListener("submit", (e) => {
    e.preventDefault();
    recentArray.unshift(input_search.value);
    console.log(recentArray);
    renderRecent();
});

function renderRecent() {
    let recent_search_html = '';
    recentArray.forEach((el) => {
        recent_search_html += `
            <div class="recent_list">
                <i class="fa-solid fa-magnifying-glass"></i>
                <a>${el}</a>
            </div>`;
    });
    recent_searchEl.innerHTML = recent_search_html;
}

renderRecent();

/*******feature ProductNav js*****/
let featureProduct_listEl = document.querySelector(".featureProduct_list");
let featureProductListHTML = '';

featureProductNav.forEach(el => {
    featureProductListHTML += `
        <div class="featureProducts_item">
            <a href="${el.link}">
                <div class="featureProduct_image">
                    <img src="${el.img}"/>
                </div>
                <p class="featureProduct_name">
                    ${el.name}
                    ${el.subNavigation ? '<i class="fa-solid fa-angle-down"></i>' : ""}
                </p>
            </a>
        </div>
    `;
});

featureProduct_listEl.innerHTML = featureProductListHTML;

/******* image Slider ******/
let imageSliderListEl = document.querySelector(".imageSliderList");
let imageSliderListHTML = '';

imageSlider.forEach(el => {
    imageSliderListHTML += `
        <div class="imageSliderItem">
            <a href="${el.link}">
                <img src="${el.image}" alt="Slider Image"/>
            </a>
        </div>
    `;
});

imageSliderListEl.innerHTML = imageSliderListHTML;

let preve_imageBtnEl = document.getElementById("preve_imageBtn");
let next_imageBtnEl = document.getElementById("next_imageBtn");

let start = 0;
let end = -400;

preve_imageBtnEl.addEventListener("click", handlePreveImage);
next_imageBtnEl.addEventListener("click", handleNextImage);

function handlePreveImage() {
    let imageallList = document.querySelectorAll(".imageSliderItem");
    if (start < 0)
        start += 100;
    imageallList.forEach(el => {
        el.style.transition = "transform 0.5s ease-in-out";
        el.style.transform = `translateX(${start}%)`;
    });
}

function handleNextImage() {
    let imageallList = document.querySelectorAll(".imageSliderItem");
    if (start > end)
        start -= 100;
    imageallList.forEach(el => {
        el.style.transition = "transform 0.5s ease-in-out";
        el.style.transform = `translateX(${start}%)`;
    });
}

function renderImagesSlider() {
    if (start > end) {
        handleNextImage();
    } else {
        start = 100; // Reset start position
    }
}

setInterval(renderImagesSlider, 3000);

/******************** bestofElectronic_product_item ************/
let bestofElectronic_product_itemEl = document.querySelector(".bestofElectronic_product_item");
let bestofElectronicsProduct_html = "";

console.log(electronicsProductData);

electronicsProductData.forEach(el => {
    bestofElectronicsProduct_html += `
        <div class="bestofElectronics_item">
            <a href="${el.link}" class="image-zoom">
                <div class="bestofElectronic_image_Product">
                    <img src="${el.img}"/>    
                </div>

                <div class="bestofElectronicMoreOption">
                    <p class="bestofElectronicsProduct_name">${el.name}</p>
                    <p class="bestofElectronic_Discount">${el.discount}</p>
                    <p class="bestofElectronic_brand">${el.brand}</p>
                </div>
            </a>
        </div>
    `
})

bestofElectronic_product_itemEl.innerHTML = bestofElectronicsProduct_html;

/*************************  fashion Top Deal *******************/
let fashion_product_itemEl = document.querySelector(".fashion_product_item");
let fashion_product_HTML = "";

console.log(fashionProductData);

fashionProductData.forEach(el => {
    fashion_product_HTML += `
    <div class="fashion_item image-border">
    <a href="${el.link}" class="image-zoom">
        <div class="fashion_image_Product">
            <img src="${el.img}" alt="${el.name}"/>    
        </div>
        <div class="fashionMoreOption">
            <p class="fashionProduct_name">${el.name}</p>
            <p class="fashion_Discount">${el.discount}</p>
        </div>
    </a>
    </div>

    `
})

fashion_product_itemEl.innerHTML = fashion_product_HTML;

/**************************** homeKitchen **************************/ 
let homeKitchen_product_itemEl = document.querySelector(".homeKitchen_product_item");
let homeKitchen_product_HTML = "";

console.log(homeKitchenProductData);

homeKitchenProductData.forEach(el => {
    homeKitchen_product_HTML += `
        <div class="homeKitchen_item image-border">
        <a href="${el.link}" class="image-zoom">
            <div class="homeKitchen_image_Product">
                <img src="${el.img}" alt="${el.name}"/>    
            </div>
            <div class="homeKitchenMoreOption">
                <p class="homeKitchenProduct_name">${el.name}</p>
                <p class="homeKitchen_Discount">${el.discount}</p>
                
            </div>
        </a>
    </div>
    `
})

homeKitchen_product_itemEl.innerHTML = homeKitchen_product_HTML;




